# AgentPing SDK for TypeScript

Production observability for AI agents. Spend, Pulse, Verify.

## Install

```bash
npm install @agentping/sdk
```

Node 18 or later. ESM only.

## Quickstart

```ts
import * as agentping from "@agentping/sdk";

agentping.init({ apiKey: process.env.AGENTPING_API_KEY });

const run = agentping.run("support-triage", { customerId: "cust_123" });
run.event("log", { message: "classified ticket" });
run.event("llm_call", {
  provider: "anthropic",
  model: "claude-sonnet-4-5",
  input_tokens: 1024,
  output_tokens: 312,
  latency_ms: 1430,
});
await run.finish({ status: "success", scores: { confidence: 0.93 } });
```

`run.id` is populated synchronously before any network call. Safe to log, store, and return to your caller immediately.

## Heartbeats

For cron jobs and one-shot scripts:

```ts
agentping.heartbeat("daily-summary", {
  status: "ok",
  costUsd: 0.084,
  durationMs: 12_300,
  metadata: { rows: 421 },
});
```

## Auto-instrumentation

Wrap a provider client to capture `llm_call` events automatically. No globals are monkey-patched.

```ts
import Anthropic from "@anthropic-ai/sdk";
import OpenAI from "openai";

const run = agentping.run("answer-bot");
const anthropic = agentping.instrumentAnthropic(new Anthropic(), { run });
const openai = agentping.instrumentOpenAI(new OpenAI(), { run });

const reply = await anthropic.messages.create({
  model: "claude-sonnet-4-5",
  max_tokens: 1024,
  messages: [{ role: "user", content: "hi" }],
});
```

Streams are supported. Token counts accumulate as chunks arrive; the `llm_call` event is emitted when the stream ends. The wrapper never delays yielding chunks to your code.

## Contract guarantees

The SDK is built to never block, crash, or leak resources in your agent's hot path.

- **Non-blocking.** All HTTP is fire-and-forget through a background queue.
- **Hard 2s timeout** on every request via `AbortController`.
- **Bounded queue.** Default 1000 envelopes. When full, the oldest is dropped and counted.
- **Batched flushes.** Up to 50 envelopes per request, every 2 seconds or when full.
- **Exponential back-off** on retryable failures; honours `Retry-After`. Gives up after 5 attempts.
- **One warning per error class** (`auth_error`, `network_error`, `server_error`).
- **Process exit hook** flushes pending events with a 5-second deadline.

## Status and flush

```ts
const s = agentping.status();
// { queueSize, droppedCount, lastFlushTs, lastError }

await agentping.flush({ timeoutMs: 5000 });
```

## Environment variables

- `AGENTPING_API_KEY` — team API key, format `apk_<region>_<32 hex>`.
- `AGENTPING_BASE_URL` — override the API base URL.
- `AGENTPING_PARENT_RUN` — parent run id for nested agents.

## License

MIT.
